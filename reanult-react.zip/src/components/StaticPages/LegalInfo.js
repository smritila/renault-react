import React from 'react';

function legalInfo() {
    return <div className="banner" style="background: url(assets/image/page_banner/Banner_Legal.jpg)">
    <div className="banner_into">
        <h1>
            Legal Info
        </h1>
    </div>
</div>
  <div className="container text_container">  
  </div>
  <ul>
        
              <li class="social_list">
                    <a href="" class="social">
                        <i class="fa fa-facebook"></i>
                    </a>
                </li>
                <li class="social_list">
                    <a href="" class="social">
                        <i class="fa fa-instagram"></i>
                    </a>
                </li>

                <li class="social_list">
                    <a href="" class="social">
                        <i class="fa fa-youtube"></i>
                    </a>
                </li>
    </ul>;         
            
            
                
    
}

export default legalInfo;