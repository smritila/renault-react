import React from 'react';

function listItem(props) {
    return <li>
        <a href="#">{props.title}</a>
    </li>;
}

export default listItem; 