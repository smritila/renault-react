import React from 'react';

import Layout from './hoc/Layout';
import CarModels from './containers/CarModels/CarModels';
// import LegalInfo from './components/StaticPages/LegalInfo';


function App() {
  return <Layout>
    {/* <LegalInfo /> */}
       <CarModels />
  </Layout>;
  
}

export default App;
